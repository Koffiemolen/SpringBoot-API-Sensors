package nl.coolpuntbeer.temperatureretrieveservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperatureRetrieveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
