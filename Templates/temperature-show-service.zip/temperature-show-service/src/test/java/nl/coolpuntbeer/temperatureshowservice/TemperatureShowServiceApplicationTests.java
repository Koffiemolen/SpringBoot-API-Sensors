package nl.coolpuntbeer.temperatureshowservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperatureShowServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
