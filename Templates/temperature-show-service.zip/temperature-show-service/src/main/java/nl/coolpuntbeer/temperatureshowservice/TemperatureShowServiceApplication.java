package nl.coolpuntbeer.temperatureshowservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemperatureShowServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemperatureShowServiceApplication.class, args);
	}

}
